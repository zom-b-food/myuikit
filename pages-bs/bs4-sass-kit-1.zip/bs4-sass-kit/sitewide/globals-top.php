<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0' name='viewport'/>
<meta name="description" content="">
<meta name="author" content="ui-design-engineering.com">

<script src="../assets/js/jquery-2.1.1.js" type="text/javascript"></script>
<script src="../assets/compiled/_myuikit.min.js" type="text/javascript"></script>
<link rel="icon" href="../assets/images/ui/favicon.ico" type="image/x-icon"/>
<link rel="shortcut icon" href="../assets/images/ui/favicon.ico" type="image/x-icon"/>
<link rel="apple-touch-icon-precomposed" href="../assets/images/apple-touch-icon.png"/>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
<link rel="stylesheet" href="../assets/css/bootstrap.min.css"/>
<link rel="stylesheet" href="../assets/compiled/_myuikit.min.css"/>
<link rel="stylesheet" href="../assets/css/custom.css"/>
