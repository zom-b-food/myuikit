<footer>
	<div class="container">
		<span class="text-muted">Place sticky footer content here.<br/>Created by Adam @ www.ui-design-engineering.com</span>
	</div>
</footer>