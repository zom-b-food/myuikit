<script src="../assets/js/components/popper.min.js" type="text/javascript"></script>
<script src="../assets/js/bootstrap.min.js" type="text/javascript"></script>
<script src="../assets/js/bootstrap-switch.js" type="text/javascript"></script>
<script src="../assets/js/components/accordion.js" type="text/javascript"></script>
<script src="../assets/js/components/nouislider.min.js" type="text/javascript"></script>
<script src="../assets/js/components/wow.min.js" type="text/javascript"></script>
<script src="../assets/js/components/jquery.filtertable.js" type="text/javascript"></script>
<script src="../assets/js/components/tablesort.js" type="text/javascript"></script>
<script src="../assets/js/components/jquery.beefup.min.js"></script>
